<?php
    $port = rand(49151,65535);
    while(stest($_SERVER['SERVER_NAME'],$port)){
        $port = rand(49151,65535);
    }
    $name = $_REQUEST["img"];
    $command = "docker pull hub.docker.local:5000/$name";
    shell_exec($command);
    $command = "docker run -d -p $port:4200 --name $name hub.docker.local:5000/$name";
    shell_exec($command);
    echo $port;
    function stest($ip, $portt) {
        $fp = @fsockopen($ip, $portt, $errno, $errstr, 0.1);
        if (!$fp) {
            return false;
        } else {
            fclose($fp);
            return true;
        }
    }
?>